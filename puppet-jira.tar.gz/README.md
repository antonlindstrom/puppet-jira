# jira

Puppet module for jira.

## Example usage

Include with default parameters:
```
include jira
```

## License

See [LICENSE](LICENSE) file.
